Meeting minutes
https://docs.google.com/a/singletreetech.com/document/d/1y6Yy0wgLvlOu8UbSnSDFo1QmQvnjapAMYVQj-Td1jB0/edit#